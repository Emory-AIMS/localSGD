clear all;
clc;

%% gendata
X = zeros(30,30,30);
rho = 0.1;
p=0.5;
X=sptensor((rand(size(X))<rho));

R = 5;
params.maxIter = 500;
params.gamma = 0.5;
params.nsamplsq = 200;

P = gcp_bras_cpd(X,R,params);