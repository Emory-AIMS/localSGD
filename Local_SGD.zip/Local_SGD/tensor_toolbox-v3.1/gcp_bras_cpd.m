function [P] = gcp_bras_cpd(X,R,params)
%% logit loss; sample fibar

	maxIter = params.maxIter;
	gamma = params.gamma;
	nsamplsq = params.nsamplsq;

	%% initialize
	N = ndims(X);
	sz = size(X);
	num_elements = prod(sz);
	dims = size(X);

	Uinit = cell(N,1);
	for n = dimorder(2:end)
	    Uinit{n} = rand(sz(n),R);
	end

	random_direction_array = randi([1 N],1,maxIter);

	%% begin main iter
	for iter = 1:maxIter
		
		rd_n = random_direction_array(iter);
		[tensor_idx, factor_idx] = sample_mode_n(nsamplsq, dims, rd_n);
		% Reshape the sampled tensor
		Xsamp = reshape(X(tensor_idx), dims(rd_n), []);
		Ysamp = exp(Xsamp)./(1+exp(Xsamp)) - Xsamp;
		% Perform a sampled KRP
		Zsamp = skr(U{[1:rd_n-1,rd_n+1:N]}, factor_idx);

		%% direct multi -- to be updated to mttkrp later or not?
		G_rd_n = ((Ysamp*Zsamp)) / (nsamplsq*1.0);
		U{rd_n} = U{rd_n} - gamma * G_rd_n;

	end%%end of main iter


end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Random sample fibers in mode n from tensor X
% Generate the corresponding indices for the factor matrices as a tuple
function [tensor_idx, factor_idx] = sample_mode_n(nsamplsq, dims, n)
D = length(dims);
tensor_idx = zeros(nsamplsq, D);     % Tuples that index fibers in original tensor

tensor_idx(:,n) = ones(nsamplsq, 1);
for i = [1:n-1,n+1:D]
    % Uniformly sample w.r. in each dimension besides n
    tensor_idx(:,i) = randi(dims(i), nsamplsq, 1);
end

% Save indices to sample from factor matrices
factor_idx = tensor_idx(:,[1:n-1,n+1:D]);

% Expand tensor_idx so that every fiber element is included
%tensor_idx = repelem(tensor_idx,dims(n),1); % not portable
tensor_idx = kron(tensor_idx,ones(dims(n),1)); % portable
tensor_idx(:,n) = repmat((1:dims(n))',nsamplsq,1);
tensor_idx = tt_sub2ind(dims, tensor_idx);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sample Khatri-Rao Product of a cell array of factors
% Without forming the full KR Product
function P = skr(varargin)
	
	if iscell(varargin{1}) % Input is a single cell array
	    A = varargin{1};
	else % Input is a sequence of matrices
	    A = varargin(1:end-1);
	end

	numfactors = length(A);
	matorder = numfactors:-1:1;
	idxs = varargin{end};

	%% Error check on matrices and compute number of rows in result
	ndimsA = cellfun(@ndims, A);
	if(~all(ndimsA == 2))
	    error('Each argument must be a matrix');
	end

	ncols = cellfun(@(x) size(x, 2), A);
	if(~all(ncols == ncols(1)))
	    error('All matrices must have the same number of columns.');
	end

	P = A{matorder(1)}(idxs(:,matorder(1)),:);
	for i = matorder(2:end)
	    %P = P .*A{i}(idxs(:,i),:);
	    P = bsxfun(@times, P, A{i}(idxs(:,i),:));
	end
end